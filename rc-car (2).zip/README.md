# ESP32 RC Car

รถบังคับ ESP32 + L298N ควบคุมผ่านบลูทูธ BLE จากแอป Android (สไตล์กระจกใส iOS 26)

## โครงสร้าง
- `www/index.html` — ตัวแอป (หน้าเชื่อมต่อ + หน้าควบคุมแนวนอน)
- `esp32/esp32_rc_car/esp32_rc_car.ino` — โค้ดอัปโหลดลงบอร์ด
- `.github/workflows/build.yml` — สร้างไฟล์ APK อัตโนมัติบน GitHub

## ขั้นตอน
1. อัปโหลดโค้ด `.ino` ลงบอร์ดด้วย Arduino IDE (Board: ESP32 Dev Module)
2. อัปโหลดทุกไฟล์ในโฟลเดอร์นี้ขึ้น GitHub (ต้องมี `.github/workflows/build.yml`)
3. แท็บ Actions → Build APK → Run workflow รอ ~5-8 นาที
4. ดาวน์โหลด `rc-car.apk` จากหน้า Releases (หรือ Artifacts) ติดตั้งบนมือถือ Android
