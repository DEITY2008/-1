// ESP32 RC Car - BLE (Nordic UART service), L298N
// รับคำสั่งรูปแบบ  M,ซ้าย,ขวา\n   (ค่า -255..255)
// Board: "ESP32 Dev Module"  (ESP32 core 2.x หรือ 3.x ใช้ได้ทั้งคู่)

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

#define ENA 25
#define IN1 26
#define IN2 27
#define IN3 14
#define IN4 32
#define ENB 33

#define SVC "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define RXC "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"

const int MIN_DUTY = 90;            // แรงต่ำสุดที่มอเตอร์เริ่มหมุน (ปรับได้)
const unsigned long FAILSAFE_MS = 500;
unsigned long lastCmd = 0;
String buf;

void pwmInit(int pin) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(pin, 1000, 8);
#else
  static int ch = 0;
  ledcSetup(ch, 1000, 8);
  ledcAttachPin(pin, ch);
  ch++;
#endif
}

void pwmWrite(int pin, int duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  ledcWrite(pin == ENA ? 0 : 1, duty);
#endif
}

int toDuty(int v) {
  v = abs(v);
  return v == 0 ? 0 : map(constrain(v, 1, 255), 1, 255, MIN_DUTY, 255);
}

void drive(int l, int r) {
  digitalWrite(IN1, l > 0); digitalWrite(IN2, l < 0);
  digitalWrite(IN3, r > 0); digitalWrite(IN4, r < 0);
  pwmWrite(ENA, toDuty(l));
  pwmWrite(ENB, toDuty(r));
}

class Rx : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *c) {
    auto v = c->getValue();
    for (char ch : v) {
      if (ch == '\n') {
        int a, b;
        if (sscanf(buf.c_str(), "M,%d,%d", &a, &b) == 2) {
          drive(constrain(a, -255, 255), constrain(b, -255, 255));
          lastCmd = millis();
        }
        buf = "";
      } else if (ch != '\r') {
        buf += ch;
        if (buf.length() > 32) buf = "";   // กันข้อมูลขยะ
      }
    }
  }
};

class Srv : public BLEServerCallbacks {
  void onConnect(BLEServer *s) { lastCmd = millis(); }
  void onDisconnect(BLEServer *s) {
    drive(0, 0);
    BLEDevice::startAdvertising();
  }
};

void setup() {
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pwmInit(ENA); pwmInit(ENB);
  drive(0, 0);

  BLEDevice::init("ESP32-RC-CAR");
  BLEServer *srv = BLEDevice::createServer();
  srv->setCallbacks(new Srv());
  BLEService *svc = srv->createService(SVC);
  BLECharacteristic *rx = svc->createCharacteristic(
      RXC, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  rx->setCallbacks(new Rx());
  svc->start();

  BLEAdvertising *adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SVC);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

void loop() {
  // Failsafe: ไม่ได้รับคำสั่งเกิน 0.5 วินาที = หยุดรถ
  if (millis() - lastCmd > FAILSAFE_MS) drive(0, 0);
  delay(20);
}
